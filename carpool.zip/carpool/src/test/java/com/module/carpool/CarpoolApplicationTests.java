package com.module.carpool;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarpoolApplicationTests {

	@Test
	void contextLoads() {
	}

}
